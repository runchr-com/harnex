# @runchr/harnex

Control-plane CLI for local AI stacks.

HARNEX prepares, verifies, links, updates, and uninstalls the stack around:
- OpenCode
- Ollama
- OpenWork
- PaperclipAI

## Install

```bash
npm i -g @runchr/harnex
```

Or run without global install:

```bash
npx @runchr/harnex doctor
```

## Quick Start

```bash
harnex doctor
harnex setup --yes
harnex init
harnex install all
harnex link openwork
harnex link paperclipai
harnex verify --scope all
harnex run --task "create api server"
```

## Useful Commands

- `harnex doctor`
- `harnex setup --yes`
- `harnex install <openwork|paperclipai|all>`
- `harnex update <all|shared|apps|opencode|ollama|openwork|paperclipai>`
- `harnex uninstall <all|shared|apps|opencode|ollama|openwork|paperclipai>`
- `harnex verify --scope <shared|apps|all>`
- `harnex run --task "<text>"`

## Uninstall Preview

```bash
harnex uninstall all --dry-run
```

## Repository

https://github.com/runchr-com/harnex

For full English/Korean documentation, see:
- https://github.com/runchr-com/harnex/blob/main/README.md
- https://github.com/runchr-com/harnex/blob/main/README_KO.md
